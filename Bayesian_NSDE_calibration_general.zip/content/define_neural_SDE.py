import torch
import torch.nn as nn
import numpy as np

class Net_LSV(nn.Module):
    def __init__(self, dim, timegrid, strikes_call, n_layers, vNetWidth, device,
                 rate, maturities, n_maturities, P, floating_lookback):
        super(Net_LSV, self).__init__()

        self.dim = dim
        self.timegrid = timegrid
        self.device = device
        self.strikes_call = strikes_call
        self.maturities = maturities
        self.rate = rate
        self.P = P
        self.fl = floating_lookback

        self.diffusion = Net_timegrid(dim=dim+1, nOut=1, n_layers=n_layers,
                                      vNetWidth=vNetWidth, n_maturities=n_maturities,
                                      activation="tanh", activation_output="softplus")
        self.v0 = nn.Parameter(torch.rand(1) - 3, requires_grad=True)
        self.driftV = Net_timegrid(dim=dim, nOut=1, n_layers=n_layers,
                                   vNetWidth=vNetWidth, n_maturities=n_maturities,
                                   activation="tanh")
        self.diffusionV = Net_timegrid(dim=dim, nOut=1, n_layers=n_layers,
                                       vNetWidth=vNetWidth, n_maturities=n_maturities,
                                       activation="tanh", activation_output="softplus")
        self.rho = nn.Parameter(2 * torch.rand(1) - 1, requires_grad=True)

        if self.P:
            self.zeta = Net_timegrid(dim=dim+2, nOut=2, n_layers=n_layers,
                                     vNetWidth=vNetWidth, n_maturities=n_maturities,
                                     activation="tanh")

        self.control_variate_vanilla = Net_timegrid(dim=dim+1,
                                                    nOut=len(strikes_call[0]) * n_maturities,
                                                    n_layers=3, vNetWidth=30,
                                                    n_maturities=n_maturities)

        if self.fl:
            self.control_variate_exotics = Net_timegrid(dim=dim * len(timegrid) + 2,
                                                        nOut=1, n_layers=3,
                                                        vNetWidth=20, n_maturities=n_maturities)

    def forward(self, S0, z, MC_samples, ind_T, period_length=16):
        mats = np.array(self.maturities)
        ones = torch.ones(MC_samples, 1, device=self.device)

        S_old = ones * S0
        #tune the multiplier to match your data
        multiplier = 1.5
        V_old = ones * torch.sigmoid(self.v0) * multiplier
        rho = torch.tanh(self.rho)

        if self.P:
            Y_old = torch.zeros_like(S_old)
            V_oldP = V_old.clone()

        cv_vanilla = torch.zeros(S_old.shape[0], len(self.strikes_call[0]) * len(self.maturities), device=self.device)
        price_vanilla_cv = torch.zeros(len(self.maturities), len(self.strikes_call[0]), device=self.device)
        var_price_vanilla_cv = torch.zeros_like(price_vanilla_cv)

        if self.fl:
            cv_exotics = torch.zeros(S_old.shape[0], 1, device=self.device)
            exotic_option_price = torch.zeros_like(S_old)
            running_max = S_old.clone()

        if self.P:
            path_driftYP = torch.zeros(MC_samples, len(self.timegrid), device=self.device)
            path_driftVP = torch.zeros(MC_samples, len(self.timegrid), device=self.device)
            path = torch.zeros(MC_samples, len(self.timegrid), device=self.device)

        path_diffusion = torch.ones(MC_samples, len(self.timegrid), device=self.device)
        path_diffusionV = torch.ones(MC_samples, len(self.timegrid), device=self.device)

        for i in range(1, len(self.timegrid)):
            idx = 0
            t = torch.full_like(S_old, self.timegrid[i - 1])
            h = self.timegrid[i] - self.timegrid[i - 1]

            dW = (torch.sqrt(h) * z[:, i - 1]).view(MC_samples, 1)
            dB = rho * dW + torch.sqrt(1 - rho**2) * torch.sqrt(h) * torch.randn_like(dW)

            diffusion = self.diffusion.forward_idx(idx, torch.cat([S_old, V_old], dim=1))
            driftV = self.driftV.forward_idx(idx, V_old)
            diffusionV = self.diffusionV.forward_idx(idx, V_old)

            S_new = S_old + self.rate * S_old * h + S_old * diffusion * dW
            V_new = V_old + driftV * h + diffusionV * dB

            if self.P:
                zeta = self.zeta.forward_idx(idx, torch.cat([t, S_old, V_old], dim=1))
                driftY_P = self.rate - 0.5 * diffusion**2 + diffusion**2 * zeta[:, 0:1] + \
                           rho * diffusion * diffusionV * zeta[:, 1:2]
                driftV_P = driftV + rho * diffusion * diffusionV * zeta[:, 0:1] + \
                           diffusionV**2 * zeta[:, 1:2]

                dWP = dW - zeta[:, 0:1] * diffusion + zeta[:, 1:2] * rho * diffusionV
                dBP = dB - zeta[:, 1:2] * torch.sqrt(1 - rho**2) * diffusionV

                Y_new = driftY_P * h + diffusion * dWP
                V_newP = V_oldP + driftV_P * h + diffusionV * dBP

            cv_vanilla += torch.exp(-self.rate * self.timegrid[i - 1]) * \
                          S_old.detach() * diffusion.detach() * \
                          self.control_variate_vanilla.forward_idx(idx, torch.cat([t, S_old.detach()], dim=1)) * \
                          dW.repeat(1, len(self.strikes_call[0]) * len(self.maturities))

            if self.fl:
                flat_path = path[:, :i].reshape(MC_samples, -1)
                cv_exotics += torch.exp(-self.rate * self.timegrid[i - 1]) * \
                              S_old.detach() * diffusion.detach() * \
                              self.control_variate_exotics.forward_idx(idx, torch.cat([t, flat_path, V_old.detach()], dim=1)) * dW

            S_old = S_new
            V_old = torch.clamp(V_new, min=0)
            path_diffusion[:, i] = diffusion.squeeze(1)
            path_diffusionV[:, i] = diffusionV.squeeze(1)

            if self.P:
                Y_old = Y_new
                V_oldP = V_newP
                path_driftYP[:, i] = driftY_P.squeeze(1)
                path_driftVP[:, i] = driftV_P.squeeze(1)
                path[:, i] = Y_old.squeeze(1)

            if i in self.maturities:
                ind_maturity = np.where(mats == i)[0][0]
                for idx_strike, strike in enumerate(self.strikes_call[ind_maturity]):
                    cv = cv_vanilla.view(-1, len(self.maturities), len(self.strikes_call[0]))
                    price_vanilla = torch.exp(-self.rate * self.timegrid[i]) * \
                                    torch.clamp(S_old - strike, min=0).squeeze(1) - cv[:, ind_maturity, idx_strike]
                    price_vanilla_cv[ind_maturity, idx_strike] = price_vanilla.mean()
                    var_price_vanilla_cv[ind_maturity, idx_strike] = price_vanilla.var()

            if self.fl:
                running_max = torch.max(running_max, S_old)
                exotic_option_price = running_max - S_old
                error = torch.exp(-self.rate * self.timegrid[i]) * exotic_option_price.detach() - \
                        torch.mean(torch.exp(-self.rate * self.timegrid[i]) * exotic_option_price.detach()) - cv_exotics.detach()
                exotic_option_price = torch.exp(-self.rate * self.timegrid[i]) * exotic_option_price - cv_exotics

        if self.P and self.fl:
            return price_vanilla_cv, var_price_vanilla_cv, exotic_option_price, \
                   exotic_option_price.mean(), exotic_option_price.var(), error, \
                   path_diffusion, path_diffusionV, path_driftYP, path_driftVP, path

        elif self.P:
            return price_vanilla_cv, var_price_vanilla_cv, path_diffusion, path_diffusionV, \
                   path_driftYP, path_driftVP, path

        elif self.fl:
            return price_vanilla_cv, var_price_vanilla_cv, exotic_option_price, \
                   exotic_option_price.mean(), exotic_option_price.var(), error, \
                   path_diffusion, path_diffusionV

        else:
            return price_vanilla_cv, var_price_vanilla_cv, path_diffusion, path_diffusionV
