import torch
from torch.optim import Optimizer


class Langevin_sampler(Optimizer):
    """ Langevin Dynamics for neural SDEs.
    """
    def __init__(self,
                 params,
                 lr=1e-4,
                 weight_decay=0) -> None:
        """ Set up a SGLD Optimizer.

        Parameters
        ----------
        params : iterable
            Parameters serving as optimization variable.
        lr : float, optional
            Base learning rate for this optimizer.
            Default: `1e-4`.
        """
        if lr < 0.0:
            raise ValueError("Invalid learning rate: {}".format(lr))
        if weight_decay < 0.0:
            raise ValueError(f"Invalid weight_decay value: {weight_decay}")

        defaults = dict(
            lr=lr,
            weight_decay=weight_decay
        )
        super().__init__(params, defaults)

    def step(self, closure=None):
        loss = None

        if closure is not None:
            loss = closure()

        for group in self.param_groups:
            for parameter in group["params"]:

                if parameter.grad is None:
                    continue

                state = self.state[parameter]
                lr = group["lr"]
                weight_decay = group['weight_decay']
                gradient = parameter.grad.data

                #  State initialization {{{ #

                if len(state) == 0:
                    state["iteration"] = 0

                #  }}} State initialization #

                state["iteration"] += 1

                # Add weight decay term (prior)
                if weight_decay != 0:
                    gradient = gradient.add(parameter, alpha=weight_decay)

                sigma = 1. / torch.sqrt(torch.tensor(lr))
                
                # Add noise (Langevin dynamics)
                scaled_grad = (
                    0.5 * gradient+
                    torch.normal(
                        mean=torch.zeros_like(gradient),
                        std=torch.ones_like(gradient)
                    ) * sigma 
                )

                parameter.data.add_(-lr * scaled_grad)

        return loss