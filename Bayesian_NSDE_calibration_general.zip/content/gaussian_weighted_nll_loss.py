import torch
import math

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

def gaussian_nll_loss(input, target, var, weights,full = True, eps = 1e-6, reduction = "mean"):
    r"""Gaussian negative log likelihood loss.

    See :class:`~torch.nn.GaussianNLLLoss` for details.

    Args:
        input: expectation of the Gaussian distribution.
        target: sample from the Gaussian distribution.
        var: tensor of positive variance(s), one for each of the expectations
            in the input (heteroscedastic), or a single one (homoscedastic).
        full (bool, optional): include the constant term in the loss calculation. Default: ``False``.
        eps (float, optional): value added to var, for stability. Default: 1e-6.
        reduction (str, optional): specifies the reduction to apply to the output:
            ``'none'`` | ``'mean'`` | ``'sum'``. ``'none'``: no reduction will be applied,
            ``'mean'``: the output is the average of all batch member losses,
            ``'sum'``: the output is the sum of all batch member losses.
            Default: ``'mean'``.
    """

    # Check var size
    # If var.size == input.size, the case is heteroscedastic and no further checks are needed.
    # Otherwise:
    if var.size() != input.size():

        # If var is one dimension short of input, but the sizes match otherwise, then this is a homoscedastic case.
        # e.g. input.size = (10, 2, 3), var.size = (10, 2)
        # -> unsqueeze var so that var.shape = (10, 2, 1)
        # this is done so that broadcasting can happen in the loss calculation
        if input.size()[:-1] == var.size():
            var = torch.unsqueeze(var, -1)

        # This checks if the sizes match up to the final dimension, and the final dimension of var is of size 1.
        # This is also a homoscedastic case.
        # e.g. input.size = (10, 2, 3), var.size = (10, 2, 1)
        elif input.size()[:-1] == var.size()[:-1] and var.size(-1) == 1:  # Heteroscedastic case
            pass

        # If none of the above pass, then the size of var is incorrect.
        else:
            raise ValueError("var is of incorrect size")
    if weights == 'none':
        weights = torch.ones(len(target[0,:]))
    # Check validity of reduction mode
    if reduction != 'none' and reduction != 'mean' and reduction != 'sum':
        raise ValueError(reduction + " is not valid")

    # Entries of var must be non-negative
    if torch.any(var < 0):
        raise ValueError("var has negative entry/entries")

    # Clamp for stability
    var = var.clone()
    with torch.no_grad():
        var.clamp_(min=eps)

    # Calculate the loss
    loss = 0.5 * (torch.log(var) + weights*((input - target)**2) / var)
    if full:
        loss += 0.5 * math.log(2 * math.pi)

    if reduction == 'mean':
        return loss.mean()
    elif reduction == 'sum':
        return loss.sum()
    else:
        return loss


def h_YV_theta(Y, V, b_Y, b_V, sigma_Y, sigma_V, rho, dt):
    """
    Compute h(Y, V | theta) in a batched manner.

    Parameters:
        Y (torch.Tensor): Shape (1, T), values of Y at different time steps.
        V (torch.Tensor): Shape (1, T), values of V at different time steps.
        b_Y (torch.Tensor): Shape (M, T), drift term for Y.
        b_V (torch.Tensor): Shape (M, T), drift term for V.
        sigma_Y (torch.Tensor): Shape (M, T), volatility term for Y.
        sigma_V (torch.Tensor): Shape (M, T), volatility term for V.
        rho (torch.Tensor): Shape (M, 1), correlation coefficient.
        dt (torch.Tensor): Shape (1, T-1), time step sizes.

    Returns:
        torch.Tensor: Shape (M,), likelihood values for each set of parameters.
    """
    M, T = sigma_Y.shape  # Extract batch size (M) and number of time steps (T)

    # Expand Y and V to shape (M, T) for broadcasting
    Y_exp = torch.transpose(Y,0,1)
    V_exp = torch.transpose(V,0,1)

    # Compute psi terms (M, T-1)
    psi_Y = (Y_exp[:,:-1] - b_Y[:,:-1]* dt) / (torch.sqrt(V_exp[:,:-1]) * torch.sqrt(dt))
    psi_V = (V_exp[:, 1:] - V_exp[:, :-1] - b_V[:, :-1] * dt) / (sigma_V[:, :-1] * torch.sqrt(dt))

    # Compute the normalizing constant (M, 1)
    norm_const = torch.log(torch.tensor(2*torch.pi,device=device))+0.5*torch.log(torch.tensor(1-rho**2,device=device))

    # Compute the exponent term (M, T-1)
    exponent = 1 / (2 * (1 - rho**2)) * (psi_Y**2 - 2 * rho * psi_Y * psi_V + psi_V**2)

    # Compute the likelihood (M,)
    likelihood = torch.sum(torch.log(norm_const) + psi_Y**2, dim=1)

    return likelihood.mean()
