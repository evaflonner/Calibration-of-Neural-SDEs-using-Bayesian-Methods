def get_weight_initializer(gain):
    def init_weights(m):
        if isinstance(m, nn.Linear):
            nn.init.xavier_normal_(m.weight.data, gain=gain)
    return init_weights