import torch
import numpy as np
import random

from define_neural_SDE import *
from gaussian_weighted_nll_loss import *
from prior_initializer import *
from langevin_sampler import *
from train_neural_SDE import *
from torch.utils.data import DataLoader

### reprdocuability
### run on A100 GPU in Google Colab
np.random.seed(43)
torch.manual_seed(43)
random.seed(43)  # Python's built-in random seed
torch.manual_seed(43)  # PyTorch seed for CPU
torch.cuda.manual_seed(43)  # PyTorch seed for current GPU
torch.cuda.manual_seed_all(43)  # PyTorch seed for all GPUs

################## RUN NEURAL SDE CALIBRATION ######################

### let s be the number of strikes
### let m be the number of maturities
### 'strikes_call' - m \times s numpy array
### 'maturities' - 1 \times m numpy array
### 'data_options - m \times s torch tensor
### 'Y_T' and 'v_T' - 1 \times len(timegrid) torch tensor

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

n_steps=96
timegrid = torch.linspace(0,1,n_steps+1).to(device)
maturity_times=np.linspace(16,96,6)
n_maturities = len(maturities)

S0 = 1
rate = 0.025 # risk-free rate

model = Net_LSV(dim=1, timegrid=timegrid, strikes_call=strikes_call*S0, n_layers=5, vNetWidth=100, device=device, n_maturities=n_maturities, maturities=maturity_times, rate = rate, P=True, floating_lookback=True)
#### Example Usage:
gain_value = 3
v_init = 0.004
model.apply(get_weight_initializer(gain_value))
model.to(device)

    # Monte Carlo test data
MC_samples_test=10000
z_test = torch.randn(MC_samples_test, n_steps, device=device)
z_test = torch.cat([z_test, -z_test], 0) # We will use antithetic Brownian paths for testing

MC_samples_train=2500
z_train = torch.randn(MC_samples_train, n_steps, device=device)
z_train = torch.cat([z_train, -z_train], 0) # We will use antithetic Brownian paths for training
loader = DataLoader(z_train, batch_size=z_train.shape[0], shuffle=False)

CONFIG = {"batch_size":5000,
            "n_epochs":1000,
            "maturities":maturity_times,
            "ttms":maturities,
            "n_maturities":4,
            "strikes_call":strikes_call*S0,
            "timegrid":timegrid,
            "n_steps":n_steps,
            "target_data":data_options.astype(np.float32), # Convert target_data to float32
            "fan_in":100,
            "fan_out":100,
            "gain":gain_value,
            "delta_val_sq":6,
            "weights":weights,
            "target_data_Y":torch.tensor(Y_T,device=device, dtype=torch.float32), 
            "target_data_V":torch.tensor(v_T,device=device, dtype=torch.float32),
            "v_init":v_init}

### choose right training algorithm to calibrate to Q, P, exotics and combinations thereof
model= train_nsde_exotics_P_Q(model, z_test, z_train, CONFIG)