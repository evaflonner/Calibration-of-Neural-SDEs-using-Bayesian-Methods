import torch
import time
import tqdm
import torch.nn as nn
import torch.nn.functional as F


# Device configuration
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

def compute_weight_decay(config):
    fan_in = config["fan_in"]
    fan_out = config["fan_out"]
    delta_val_sq = config["delta_val_sq"]
    gain = config["gain"]
    sigma_prior = gain * torch.sqrt(torch.tensor(2.0 / (fan_in + fan_out)))
    return delta_val_sq / sigma_prior**2

def freeze_model_parts(model, freeze_sde=True):
    if freeze_sde:
        model.control_variate_vanilla.unfreeze()
        if hasattr(model, 'control_variate_exotics'):
            model.control_variate_exotics.unfreeze()

        model.diffusion.freeze()
        model.driftV.freeze()
        model.diffusionV.freeze()
        model.v0.requires_grad_(False)
        model.rho.requires_grad_(False)
    else:
        model.control_variate_vanilla.freeze()
        if hasattr(model, 'control_variate_exotics'):
            model.control_variate_exotics.freeze()

        model.diffusion.unfreeze()
        model.driftV.unfreeze()
        model.diffusionV.unfreeze()
        model.v0.requires_grad_(True)
        model.rho.requires_grad_(True)

def run_training_loop(model, z_test, config, optimizer_SDE, optimizer_CV, mode="vanilla"):
    n_epochs = config["n_epochs"]
    batch_size = config["batch_size"]
    T = 1.0
    target_mat_T = config["target_data"][:len(config["maturities"]), :len(config["strikes_call"])]
    delta_val = config["delta_sq_val"]
    v_init = config["v_init"]
    vega_weights = config["weights"]
    loss_val = nn.MSELoss()
    itercount = 0

    for epoch in tqdm.trange(n_epochs, desc="Training"):
        print(f"Epoch: {epoch}")

        requires_grad_CV = (epoch + 1) % 2 == 0
        freeze_model_parts(model, freeze_sde=requires_grad_CV)

        batch_z = torch.cat([x for x in config['loader']], dim=0)

        for i in range(0, 20 * batch_size, batch_size):
            optimizer_SDE.zero_grad()
            optimizer_CV.zero_grad()
            init_time = time.time()

            if mode == "exotics_P_Q":
                pred, var, exotic_price, exotic_mean, exotic_var, error, diff, diffV, driftY, driftV, path = model(
                    config['S0'], batch_z, batch_size, T, period_length=16
                )
            elif mode == "P_Q":
                pred, var, diff, diffV, driftY, driftV, path = model(config['S0'], batch_z, batch_size, T, period_length=16)
            elif mode == "exotics":
                pred, var, exotic_price, exotic_mean, exotic_var, error, diff, diffV = model(config['S0'], batch_z, batch_size, T, period_length=16)
            else:
                pred, var, diff, diffV = model(config['S0'], batch_z, batch_size, T, period_length=16)

            time_forward = time.time() - init_time
            itercount += 1

            if requires_grad_CV:
                loss = var.sum()
                loss.backward()
                nn.utils.clip_grad_norm_(list(model.control_variate_vanilla.parameters()), 3)
                optimizer_CV.step()
            else:
                delta = torch.ones_like(target_mat_T, device=device) * delta_val
                loss_options = gaussian_nll_loss(pred, target_mat_T, delta.to(device), vega_weights.to(device), reduction="sum")

                if mode in ["P_Q", "exotics_P_Q"]:
                    loss_ts = h_YV_theta(
                        config["target_data_Y"], config["target_data_V"],
                        driftY, driftV, diff, diffV,
                        torch.ones(1, device=device) * v_init,
                        torch.ones(1, device=device) / len(config["target_data_Y"])
                    )
                    loss = loss_options + loss_ts
                else:
                    loss = loss_options

                loss.backward()
                nn.utils.clip_grad_norm_(model.parameters(), 5)
                optimizer_SDE.step()

            print(f"Iteration {itercount}, Loss: {loss.item():.4f}, Forward: {time_forward:.4f}s")

        # Evaluate RMSE
        with torch.no_grad():
            eval_out = model(config['S0'], z_test, z_test.shape[0], T, period_length=16)
            pred = eval_out[0]
            rmse = torch.sqrt(loss_val(pred, target_mat_T))
            print(f"Validation RMSE: {rmse:.4f}")

    return model

def setup_and_train(model, z_test, z_train, config, mode="vanilla"):
    model = model.to(device)
    model.apply(init_weights)

    params_SDE = list(model.diffusion.parameters()) + \
                 list(model.driftV.parameters()) + \
                 list(model.diffusionV.parameters()) + \
                 list(getattr(model, 'zeta', nn.ParameterList()).parameters()) + \
                 [model.rho, model.v0]

    weight_decay = compute_weight_decay(config)
    optimizer_SDE = Langevin_sampler(params_SDE, lr=1e-4, weight_decay=weight_decay)

    cv_params = list(model.control_variate_vanilla.parameters())
    if mode in ["exotics", "exotics_P_Q"]:
        cv_params += list(model.control_variate_exotics.parameters())

    optimizer_CV = torch.optim.SGD(cv_params, lr=1e-3)

    return run_training_loop(model, z_test, config, optimizer_SDE, optimizer_CV, mode=mode)


# Aliases for various training regimes
def train_nsde(model, z_test, z_train, config):
    return setup_and_train(model, z_test, z_train, config, mode="vanilla")

def train_nsde_exotics(model, z_test, z_train, config):
    return setup_and_train(model, z_test, z_train, config, mode="exotics")

def train_nsde_P_Q(model, z_test, z_train, config):
    return setup_and_train(model, z_test, z_train, config, mode="P_Q")

def train_nsde_exotics_P_Q(model, z_test, z_train, config):
    return setup_and_train(model, z_test, z_train, config, mode="exotics_P_Q")